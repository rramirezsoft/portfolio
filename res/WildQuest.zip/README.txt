# Instrucciones para ejecutar WildQuest

¡Bienvenido a WildQuest! A continuación, te proporcionamos las instrucciones para ejecutar el juego en tu sistema.

## Requisitos
- **Java Runtime Environment (JRE)**: Para ejecutar este juego, necesitas tener instalado el **JRE** de Java en tu ordenador. Si aún no lo tienes, puedes descargarlo desde el siguiente enlace:
  - [Descargar JRE](https://www.java.com/es/download/)

## Ejecución del juego

### 1. Ejecutar el archivo JAR
- Dentro de la carpeta `WildQuest`, encontrarás el archivo **WildQuest_beta.jar**.
- **Para ejecutar el juego**:
  - En **Windows**, haz doble clic en el archivo `.jar` (asegúrate de que el JRE esté correctamente instalado).
  - En **Mac/Linux**, abre una terminal y navega hasta la carpeta donde está el archivo `WildQuest.jar` y ejecuta el siguiente comando:
  
    ```bash
    java -jar WildQuest.jar
    ```

### 2. Archivos generados automáticamente
- **config.txt**: Al ejecutar el juego por primera vez, se generará un archivo llamado `config.txt` en la misma carpeta. Este archivo contiene configuraciones de pantalla, sonido y otros ajustes que puedes modificar si lo deseas.
- **save.dat**: Cuando guardes tu partida por primera vez, se generará un archivo `save.dat` para guardar tu progreso. El juego guardará automáticamente tu progreso allí cada vez que guardes la partida. Si deseas empezar una nueva partida, puedes hacerlo pulsando "Nueva Partida" dentro del juego y al guardar el progreso de la nueva partida, automáticamente sobrescribirá el contenido del `sabe.dat`

## Sugerencia
- Mantén el juego en su propia carpeta para que todos los archivos generados (como `config.txt` y `save.dat`) se guarden correctamente en el mismo lugar.

## Soporte
Si tienes algún problema o necesitas soporte adicional, puedes contactarme a través de mi página web: [rramirezsoft.com](https://rramirezsoft.com).

---

¡Gracias por jugar y disfrutar de **WildQuest**!
